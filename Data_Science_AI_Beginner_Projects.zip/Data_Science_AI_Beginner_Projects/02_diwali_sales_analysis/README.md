# Diwali Sales Mini Analysis

**Goal:** Practice exploratory data analysis on a small sample shopping dataset.

**Methods:** Pandas, groupby summaries, sorting, Matplotlib bar chart.

**Important:** `diwali_sample.csv` is made-up sample data for practice and must not be described as real customer data.

**Run:** `python diwali_analysis.py`

**Possible next step:** Replace the sample CSV with a dataset you are permitted to use, then update the README to describe its source.
