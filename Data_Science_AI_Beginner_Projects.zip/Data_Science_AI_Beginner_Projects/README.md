# Beginner Data Science & AI Projects

A beginner-friendly portfolio repository with three small projects suitable for learning and practice.

## Projects
1. **Iris Flower Classification (Machine Learning)** — trains a Decision Tree model using the built-in Iris dataset from scikit-learn.
2. **Diwali Sales Mini Analysis (Data Analysis)** — analyzes a sample dataset with Pandas and creates charts with Matplotlib.
3. **Student Score Prediction (Machine Learning)** — trains a Linear Regression model on a small sample dataset.

> These are learning/demo projects. The Diwali and student-score CSV files are sample data created for practice, not real survey or school records.

## Requirements
- Python 3.9+
- pandas
- matplotlib
- scikit-learn

Install dependencies:
```bash
pip install -r requirements.txt
```

## Run each project
From the repository root:
```bash
python 01_iris_classification/iris_classification.py
python 02_diwali_sales_analysis/diwali_analysis.py
python 03_student_score_prediction/student_score_prediction.py
```

## Skills practiced
Python, data cleaning, exploratory data analysis (EDA), data visualization, train/test split, classification, regression, model evaluation.

## GitHub upload
1. Extract this ZIP file.
2. Sign in to GitHub and create a new repository, e.g. `data-science-ai-beginner-projects`.
3. Open the repository page and choose **Add file → Upload files**.
4. Upload the extracted project files/folders, then click **Commit changes**.

Alternatively, from a terminal inside the extracted folder:
```bash
git init
git add .
git commit -m "Add beginner Data Science and AI projects"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/data-science-ai-beginner-projects.git
git push -u origin main
```
Replace `YOUR-USERNAME` with your GitHub username. Do not share your password or access token.
