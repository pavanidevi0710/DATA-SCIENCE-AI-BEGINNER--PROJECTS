# Iris Flower Classification

**Goal:** Predict an Iris flower species from four measurements.

**Methods:** Built-in scikit-learn Iris dataset, train/test split, Decision Tree classifier, accuracy and classification report.

**Run:** `python iris_classification.py`

**Interview explanation:** I loaded a standard sample dataset, split it into training and testing sets, trained a Decision Tree classifier, and evaluated predictions on unseen test data.
