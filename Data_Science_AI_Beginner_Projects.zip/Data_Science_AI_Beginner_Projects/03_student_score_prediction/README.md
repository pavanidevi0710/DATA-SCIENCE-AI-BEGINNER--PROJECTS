# Student Score Prediction

**Goal:** Demonstrate regression using study hours and attendance percentage.

**Methods:** Pandas, train/test split, Linear Regression, MAE and R-squared.

**Important:** The data is synthetic practice data, not real student records or a validated educational model.

**Run:** `python student_score_prediction.py`
